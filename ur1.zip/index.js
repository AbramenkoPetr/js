const colors = require("colors/safe");
let prArr = [];
console.log(process.argv[2] + " " + process.argv[3]);
let min = Number(process.argv[2]);
let max = Number(process.argv[3]);
console.log(min + ' ' + max);
if ( Number.isNaN(min) || Number.isNaN(max) )  {
console.log('Аргумент не является числом');
return;
}
//let s = min + max;
let nPrime = 0;
for (i = min; i <= max; i++)    {
    if (isPrime(i)) {
        //console.log(i);
        prArr [nPrime] = i;
        //console.log(prArr[nPrime] + ' ' + nPrime);
        nPrime = nPrime +1;
        
    }
}

//console.log(nPrime);
if (!nPrime) {
console.log(colors.red('Простых чисел в диапазоне нет'));
return;}
let j = 0;
do {
console.log(colors.green(prArr[j]));
if (j >= nPrime -1) return;
j++;
console.log(colors.yellow(prArr[j]));
if (j >= nPrime -1) return;
j++;
console.log(colors.red(prArr[j]));
if (j >= nPrime -1) return;
j++;
} while (j=j);
function isPrime(num) {
    for(let i = 2; i < num; i++)
      if(num % i === 0) return false;
    return num > 1;
  }